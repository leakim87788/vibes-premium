# Vibes Premium — projeto Android

Projeto nativo em Kotlin + Jetpack Compose, com interface escura premium.

## O que está implementado
- Feed de vídeos de demonstração
- Busca por título, criador e categoria
- Aba de favoritos (por enquanto, em memória durante a sessão)
- Botão de download usando o DownloadManager do Android para links diretos MP4
- Notificação do Android quando o download termina
- Tela de detalhes para cada vídeo

## Como executar
1. Abra a pasta `VibesPremium` no Android Studio recente.
2. Aguarde o Gradle sincronizar e instalar as dependências.
3. Execute em um emulador ou celular Android conectado.

## Limites desta versão
- Este arquivo contém o código-fonte do projeto Android Studio, não um APK compilado.
- Os vídeos são links diretos de demonstração e precisam de internet.
- O app não extrai vídeos do YouTube nem contorna restrições de plataformas.
- Favoritos ainda não são persistidos após fechar o app; isso pode ser adicionado numa próxima versão.
- Android 8.0 (API 26) ou superior.
