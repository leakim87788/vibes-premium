package com.vibespremium.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090B12)
private val Panel = Color(0xFF151925)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF39D0C8)
private val Muted = Color(0xFF9CA3AF)

data class ClipItem(val id: Int, val title: String, val creator: String, val category: String, val duration: String, val videoUrl: String)

private val sampleClips = listOf(
    ClipItem(1, "Ocean Dreams", "Vibes Studio", "Natureza", "00:30", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
    ClipItem(2, "Big Buck Bunny", "Open Movie", "Animação", "00:10", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
    ClipItem(3, "Aventura em movimento", "Vibes Studio", "Aventura", "00:15", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"),
    ClipItem(4, "Pequenas grandes ideias", "Creative Lab", "Criatividade", "00:15", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"),
    ClipItem(5, "Noite na cidade", "Vibes Studio", "Lifestyle", "00:15", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VibesApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VibesApp(context: Context) {
    var search by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var favorites by remember { mutableStateOf(setOf<Int>()) }
    var selectedClip by remember { mutableStateOf<ClipItem?>(null) }
    val visible = sampleClips.filter {
        (selectedTab != 1 || it.id in favorites) &&
            (it.title.contains(search, true) || it.creator.contains(search, true) || it.category.contains(search, true))
    }
    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Violet, secondary = Cyan, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Ink, topBar = {
            Column(Modifier.fillMaxWidth().background(Ink).padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Violet, Cyan))), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("VIBES", fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("PREMIUM", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(50)) {
                        Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Cyan, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(5.dp)); Text("SEM ANÚNCIOS", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Buscar vídeos, criadores...", color = Muted) },
                    leadingIcon = { Icon(Icons.Default.Search, "Buscar", tint = Muted) },
                    trailingIcon = { if (search.isNotEmpty()) IconButton(onClick = { search = "" }) { Icon(Icons.Default.Close, "Limpar busca") } },
                    singleLine = true, shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Violet, unfocusedBorderColor = Color(0xFF2A3040), focusedContainerColor = Panel, unfocusedContainerColor = Panel))
            }
        }, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Explore, null) }, label = { Text("Explorar") }, colors = navColors())
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Favoritos") }, colors = navColors())
            }
        }) { padding ->
            if (selectedClip != null) {
                val clip = selectedClip!!
                VideoDetails(clip, clip.id in favorites, { favorites = if (clip.id in favorites) favorites - clip.id else favorites + clip.id }, { enqueueDownload(context, clip) }, { selectedClip = null }, Modifier.padding(padding))
            } else {
                LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        Column(Modifier.padding(bottom = 2.dp)) {
                            Text(if (selectedTab == 1) "SEUS FAVORITOS" else "EM DESTAQUE", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.height(5.dp))
                            Text(if (selectedTab == 1) "Salvos para depois." else "Sua próxima vibe começa aqui.", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("${visible.size} vídeos disponíveis", color = Muted, fontSize = 13.sp)
                        }
                    }
                    if (visible.isEmpty()) item {
                        Column(Modifier.fillMaxWidth().padding(vertical = 44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.VideoLibrary, null, tint = Muted, modifier = Modifier.size(48.dp)); Spacer(Modifier.height(12.dp))
                            Text(if (selectedTab == 1) "Nenhum favorito ainda" else "Nada encontrado", fontWeight = FontWeight.Bold)
                            Text("Tente outra busca ou salve um vídeo.", color = Muted, fontSize = 13.sp)
                        }
                    }
                    items(visible, key = { it.id }) { clip ->
                        ClipCard(clip, clip.id in favorites, { selectedClip = clip },
                            { favorites = if (clip.id in favorites) favorites - clip.id else favorites + clip.id },
                            { enqueueDownload(context, clip) })
                    }
                    item { Text("Vídeos de demonstração com links diretos. Baixe apenas conteúdos que você tem autorização para salvar.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 6.dp, bottom = 8.dp)) }
                }
            }
        }
    }
}

@Composable private fun navColors() = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF26303A), unselectedIconColor = Muted, unselectedTextColor = Muted)

@Composable
fun ClipCard(clip: ClipItem, favorite: Boolean, onOpen: () -> Unit, onFavorite: () -> Unit, onDownload: () -> Unit) {
    val palettes = listOf(listOf(Color(0xFF3D2B79), Color(0xFF146B72)), listOf(Color(0xFF253E68), Color(0xFF6D3A70)), listOf(Color(0xFF126A63), Color(0xFF20294D)), listOf(Color(0xFF5B326A), Color(0xFF183E5D)), listOf(Color(0xFF704C28), Color(0xFF282A5A)))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).clickable { onOpen() }) {
        Box(Modifier.fillMaxWidth().height(174.dp).background(Brush.linearGradient(palettes[clip.id % palettes.size]))) {
            Icon(Icons.Default.PlayCircle, "Reproduzir ${clip.title}", tint = Color.White.copy(alpha = .92f), modifier = Modifier.align(Alignment.Center).size(58.dp))
            Surface(color = Color.Black.copy(alpha = .55f), shape = RoundedCornerShape(8.dp), modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)) { Text(clip.duration, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 11.sp) }
            Surface(color = Color.Black.copy(alpha = .35f), shape = RoundedCornerShape(8.dp), modifier = Modifier.align(Alignment.TopStart).padding(12.dp)) { Text(clip.category.uppercase(), Modifier.padding(horizontal = 9.dp, vertical = 5.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 8.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(clip.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); Spacer(Modifier.height(3.dp)); Text(clip.creator, color = Muted, fontSize = 12.sp) }
            IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, if (favorite) "Remover dos favoritos" else "Adicionar aos favoritos", tint = if (favorite) Color(0xFFFF6B9A) else Muted) }
            IconButton(onClick = onDownload) { Icon(Icons.Default.Download, "Baixar vídeo", tint = Cyan) }
        }
    }
}

@Composable
fun VideoDetails(clip: ClipItem, isFavorite: Boolean, onFavorite: () -> Unit, onDownload: () -> Unit, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(8.dp)); Text("Voltar") }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Violet, Color(0xFF165B72)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayCircle, "Vídeo de demonstração", tint = Color.White, modifier = Modifier.size(76.dp))
        }
        Spacer(Modifier.height(20.dp)); Text(clip.category.uppercase(), color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp)); Text(clip.title, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold); Text("por ${clip.creator}", color = Muted)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onDownload, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Baixar vídeo", fontWeight = FontWeight.Bold) }
        OutlinedButton(onClick = onFavorite, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(52.dp), shape = RoundedCornerShape(16.dp)) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (isFavorite) Color(0xFFFF6B9A) else Color.White); Spacer(Modifier.width(8.dp)); Text(if (isFavorite) "Salvo nos favoritos" else "Adicionar aos favoritos")
        }
        Spacer(Modifier.height(18.dp)); Text("Sobre este vídeo", fontWeight = FontWeight.Bold, fontSize = 16.sp); Spacer(Modifier.height(6.dp))
        Text("Seleção de demonstração do Vibes Premium. Busca, favoritos e download de links diretos estão implementados.", color = Muted, lineHeight = 21.sp)
    }
}

private fun enqueueDownload(context: Context, clip: ClipItem) {
    try {
        val request = DownloadManager.Request(Uri.parse(clip.videoUrl)).setTitle("${clip.title}.mp4").setDescription("Baixando pelo Vibes Premium").setMimeType("video/mp4")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "VibesPremium_${clip.id}.mp4")
            .setAllowedOverMetered(true).setAllowedOverRoaming(false)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(context, "Download iniciado. Confira as notificações.", Toast.LENGTH_LONG).show()
    } catch (_: Exception) { Toast.makeText(context, "Não foi possível iniciar o download.", Toast.LENGTH_LONG).show() }
}
